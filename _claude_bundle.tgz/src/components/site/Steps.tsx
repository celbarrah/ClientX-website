import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { STEPS } from "../../lib/site";
import { Eyebrow } from "./primitives";
import { ModuleMock } from "./ModuleMock";

gsap.registerPlugin(ScrollTrigger);

export function StepsSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || window.matchMedia("(max-width: 1023px)").matches) return;

    const cards = containerRef.current?.querySelectorAll<HTMLElement>("[data-step-card]");
    if (!cards || !containerRef.current) return;

    const triggers: ScrollTrigger[] = [];
    cards.forEach((card, i) => {
      const st = ScrollTrigger.create({
        trigger: card,
        start: "top 20%",
        end: "bottom 20%",
        onEnter: () => setActive(i),
        onEnterBack: () => setActive(i),
      });
      triggers.push(st);

      if (i < cards.length - 1) {
        gsap.to(card, {
          scale: 0.94,
          opacity: 0.6,
          ease: "none",
          scrollTrigger: {
            trigger: cards[i + 1],
            start: "top bottom",
            end: "top 20%",
            scrub: true,
          },
        });
      }
    });

    return () => {
      triggers.forEach((t) => t.kill());
      ScrollTrigger.getAll().forEach((t) => {
        if (containerRef.current?.contains(t.trigger as Node)) t.kill();
      });
    };
  }, []);

  return (
    <section
      className="rails-bg py-16 md:py-24"
      style={{ backgroundColor: "#ffffff", borderTop: "1px solid var(--line)" }}
    >
      <div className="container-x">
        <Eyebrow>Développez votre business sans limite</Eyebrow>
        <h2
          className="text-balance mt-5 max-w-[40rem] font-semibold"
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "clamp(2rem,3.6vw,3.2rem)",
            letterSpacing: "-0.03em",
            color: "#000000",
          }}
        >
          4 Étapes Unifiées dans{" "}
          <span style={{ color: "var(--green-text)" }}>1 Seule Plateforme</span>
        </h2>
      </div>

      <div ref={containerRef} className="container-x mt-10 grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
        {/* Sticky step list */}
        <div className="hidden lg:block">
          <div className="sticky top-28 space-y-1">
            {STEPS.map((s, i) => (
              <div key={i} className="flex items-center gap-4 py-3">
                <span
                  className="h-1 rounded-full transition-all duration-300"
                  style={{
                    width: active === i ? 32 : 16,
                    background: active === i ? "var(--green)" : "var(--line-strong)",
                  }}
                />
                <span
                  className="text-[17px] font-medium transition-colors duration-300"
                  style={{ color: active === i ? "var(--ink)" : "var(--muted)" }}
                >
                  {s.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Stacked cards */}
        <div className="space-y-6">
          {STEPS.map((s, i) => (
            <div
              key={i}
              data-step-card
              className="card overflow-hidden p-7 md:min-h-[70vh]"
              style={{ boxShadow: "var(--shadow-md)" }}
            >
              <div className="flex items-center justify-between">
                <span
                  className="rounded-full px-3 py-1 text-[12px] font-medium"
                  style={{ background: "var(--green-soft)", color: "var(--green-text)" }}
                >
                  {s.subtitle}
                </span>
                <span
                  className="font-semibold"
                  style={{
                    fontFamily: "var(--font-display)",
                    fontSize: "clamp(2.4rem,5vw,3.5rem)",
                    color: "var(--line-strong)",
                    fontVariantNumeric: "tabular-nums",
                  }}
                >
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <h3
                className="mt-5 text-balance text-[clamp(1.5rem,2.4vw,2rem)] font-bold"
                style={{ letterSpacing: "-0.02em", color: "#000000" }}
              >
                {s.title}
              </h3>
              <p
                className="text-pretty mt-3 max-w-[42rem] text-[16px] leading-relaxed"
                style={{ color: "var(--muted)" }}
              >
                {s.desc}
              </p>
              <div
                className="mt-6 overflow-hidden rounded-2xl border"
                style={{ background: "#ffffff", borderColor: "var(--line)" }}
              >
                <div className="p-4">
                  <ModuleMock kind={s.subtitle} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

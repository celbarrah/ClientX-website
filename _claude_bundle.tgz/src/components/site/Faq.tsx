import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FAQS } from "../../lib/site";
import { Plus, X } from "@phosphor-icons/react";

const EASE = [0.16, 1, 0.3, 1] as const;

export function FaqSection() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section
      id="faq"
      className="rails-bg relative overflow-hidden py-20 md:py-24"
      style={{
        backgroundColor: "#ffffff",
        borderTop: "1px solid var(--line)",
      }}
    >
      <div className="container-x relative">
        <div className="mx-auto max-w-[760px]">
          {/* Centered header */}
          <div className="flex flex-col items-center text-center">
            <span
              className="inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em]"
              style={{
                background: "var(--green-soft)",
                color: "var(--green-text)",
              }}
            >
              FAQ
            </span>
            <h2
              className="text-balance mt-5 font-bold leading-[1.05]"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2rem, 3.6vw, 3.2rem)",
                letterSpacing: "-0.03em",
                color: "#000000",
              }}
            >
              Questions Fréquentes
            </h2>
          </div>

          {/* Hairline-separated accordion */}
          <div className="mt-12 divide-y" style={{ borderColor: "var(--line)" }}>
            {FAQS.map((faq, index) => {
              const isOpen = open === index;
              const num = String(index + 1).padStart(2, "0");

              return (
                <div key={index} className="group" style={{ borderColor: "var(--line)" }}>
                  <button
                    onClick={() => setOpen(isOpen ? null : index)}
                    aria-expanded={isOpen}
                    className="flex w-full items-start justify-between gap-6 py-6 text-left"
                  >
                    <div className="flex items-start gap-4 pr-4 md:gap-5">
                      <span
                        className="font-mono text-[12px] tracking-wider"
                        style={{
                          fontFamily: "var(--font-mono)",
                          color: isOpen ? "var(--green-text)" : "var(--faint)",
                          transition: "color 0.2s var(--ease-expo)",
                        }}
                      >
                        {num}
                      </span>
                      <span
                        className="text-[16px] font-semibold leading-snug md:text-[18px]"
                        style={{
                          color: isOpen ? "#000000" : "#1a1a1a",
                          transition: "color 0.2s var(--ease-expo)",
                        }}
                      >
                        {faq.q}
                      </span>
                    </div>

                    <span
                      className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full border transition-all duration-300"
                      style={{
                        borderColor: isOpen ? "var(--green)" : "var(--line-strong)",
                        color: isOpen ? "var(--green-text)" : "var(--muted)",
                        background: isOpen ? "var(--green-soft)" : "var(--surface)",
                      }}
                    >
                      <AnimatePresence mode="wait" initial={false}>
                        <motion.span
                          key={isOpen ? "x" : "plus"}
                          initial={{ rotate: -90, opacity: 0 }}
                          animate={{ rotate: 0, opacity: 1 }}
                          exit={{ rotate: 90, opacity: 0 }}
                          transition={{ duration: 0.2, ease: EASE }}
                          className="grid place-items-center"
                        >
                          {isOpen ? (
                            <X className="h-3.5 w-3.5" weight="bold" />
                          ) : (
                            <Plus className="h-3.5 w-3.5" weight="bold" />
                          )}
                        </motion.span>
                      </AnimatePresence>
                    </span>
                  </button>

                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.35, ease: EASE }}
                        className="overflow-hidden"
                      >
                        <div className="pb-7 pl-9 pr-2 md:pl-12">
                          <p
                            className="text-[15px] leading-relaxed md:text-[16px]"
                            style={{ color: "var(--muted)" }}
                          >
                            {faq.a}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

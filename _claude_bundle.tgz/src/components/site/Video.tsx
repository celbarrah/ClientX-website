import { useState } from "react";
import { motion } from "framer-motion";
import { Play } from "@phosphor-icons/react";
import { Eyebrow } from "./primitives";
import { VIDEO_SRC } from "../../lib/site";

const MODULE_NAMES = [
  "Sites & Tunnels de Vente",
  "CRM Systémique & Ventes",
  "Emailing & SMS Marketing",
  "Automatisations & Workflows",
  "Calendriers & Rendez-vous IA",
];

export function VideoSection() {
  const [playing, setPlaying] = useState(false);
  return (
    <section className="py-16 md:py-24" style={{ background: "var(--ink)", color: "#fff" }}>
      <div className="container-x">
        <div className="flex flex-col items-center text-center">
          <Eyebrow>Découvrez la plateforme en direct</Eyebrow>
          <h2
            className="text-balance mt-5 font-semibold"
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "clamp(2rem,3.6vw,3.2rem)",
              letterSpacing: "-0.03em",
              color: "#fff",
            }}
          >
            La puissance de ClientX AI <span style={{ color: "var(--green)" }}>en vidéo</span>
          </h2>
          <p
            className="text-pretty mt-5 max-w-[44rem] text-[17px] leading-relaxed"
            style={{ color: "rgba(255,255,255,0.7)" }}
          >
            Voyez comment centraliser l'intégralité de vos tunnels, CRM, emails, automatisations et
            calendriers en une interface fluide et ultra-rapide.
          </p>
        </div>

        <div className="relative mx-auto mt-12 max-w-[960px]">
          <div
            className="relative overflow-hidden rounded-[20px] border"
            style={{ borderColor: "rgba(255,255,255,0.12)" }}
          >
            <video
              src={`${VIDEO_SRC}#t=0.5`}
              preload="metadata"
              controls={playing}
              playsInline
              className="aspect-video w-full"
              style={{ background: "#0a0d0b" }}
            />
            {!playing && (
              <button
                onClick={() => setPlaying(true)}
                aria-label="Lire la vidéo"
                className="group absolute inset-0 flex items-center justify-center"
                style={{
                  background: "linear-gradient(180deg, rgba(10,13,11,0.2), rgba(10,13,11,0.6))",
                }}
              >
                <motion.span
                  whileHover={{ scale: 1.05 }}
                  className="grid h-[72px] w-[72px] place-items-center rounded-full bg-white"
                  style={{ boxShadow: "0 20px 50px -10px rgba(0,0,0,0.5)" }}
                >
                  <Play className="h-7 w-7 text-black" weight="fill" />
                </motion.span>
              </button>
            )}
          </div>
        </div>

        <p
          className="mt-8 text-center text-[14px] leading-relaxed"
          style={{ color: "rgba(255,255,255,0.6)" }}
        >
          {MODULE_NAMES.join(" · ")}
        </p>
      </div>
    </section>
  );
}

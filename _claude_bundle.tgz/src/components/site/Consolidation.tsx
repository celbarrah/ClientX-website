import { useEffect, useRef, useState } from "react";
import { motion, useInView, useScroll, useTransform, useMotionValueEvent } from "framer-motion";
import { CLIENTX_LOGO } from "../../lib/site";
import { SectionTitle } from "./primitives";

const TOOLS = [
  "Tunnel",
  "CRM",
  "Emailing",
  "SMS",
  "Calendrier",
  "Formation",
  "Social",
  "Automatisation",
  "Devis",
  "Signature",
  "Paiement",
  "Inbox",
  "Quiz",
  "Communauté",
  "Dashboard",
  "API",
];

/* Loose two-arc positions: 8 left, 8 right, varied vertical offsets (organic) */
const POS = [
  { side: "L", x: 4, y: 8 },
  { side: "L", x: 1, y: 26 },
  { side: "L", x: 6, y: 44 },
  { side: "L", x: 2, y: 62 },
  { side: "L", x: 7, y: 80 },
  { side: "L", x: 3, y: 92 },
  { side: "L", x: 8, y: 50 },
  { side: "L", x: 0, y: 70 },
  { side: "R", x: 4, y: 8 },
  { side: "R", x: 1, y: 26 },
  { side: "R", x: 6, y: 44 },
  { side: "R", x: 2, y: 62 },
  { side: "R", x: 7, y: 80 },
  { side: "R", x: 3, y: 92 },
  { side: "R", x: 8, y: 50 },
  { side: "R", x: 0, y: 70 },
];

export function ConsolidationSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.2 });
  const { scrollYProgress } = useScroll({
    target: ref as React.RefObject<HTMLElement>,
    offset: ["start end", "end start"],
  });

  // chips settle from scattered -> arcs as you scroll through
  const settle = useTransform(scrollYProgress, [0.1, 0.4], [0, 1]);
  const hubScale = useTransform(scrollYProgress, [0.2, 0.5], [0.7, 1]);
  const hubOpacity = useTransform(scrollYProgress, [0.2, 0.45], [0, 1]);
  const chipsDim = useTransform(scrollYProgress, [0.4, 0.6], [1, 0.6]);

  // count 20 -> 1
  const countValue = useTransform(scrollYProgress, [0.35, 0.6], [20, 1]);
  const [count, setCount] = useState(20);
  useMotionValueEvent(countValue, "change", (v) => setCount(Math.round(v)));

  return (
    <section
      className="rails-bg py-16 md:py-24"
      style={{ backgroundColor: "#ffffff", borderTop: "1px solid var(--line)" }}
    >
      <div className="container-x">
        <div
          className="relative overflow-hidden rounded-[32px] border p-6 md:p-12"
          style={{
            borderColor: "var(--line-strong)",
            background: "#ffffff",
            boxShadow: "var(--shadow-sm)",
          }}
        >
          {/* masked line grid */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 dot-bg"
            style={{ opacity: 0.5 }}
          />
          <div className="relative grid items-center gap-12 lg:grid-cols-2">
            {/* Left text */}
            <div>
              <SectionTitle>
                +20 outils. Réunis en{" "}
                <span style={{ color: "var(--green-text)" }}>1 plateforme.</span>
              </SectionTitle>
              <p
                className="text-pretty mt-5 max-w-[34rem] text-[17px] leading-relaxed"
                style={{ color: "var(--text)" }}
              >
                ClientX remplace votre outil de tunnel, votre CRM, votre système d'emailing, votre
                planificateur de rendez-vous, vos outils d'automatisation, vos hébergements de
                formation et votre planificateur social, vous faisant économiser plus de 15 000€ par
                an.
              </p>
              {/* big counter */}
              <div className="mt-8 flex items-baseline gap-3">
                <Counter20to1 inView={inView} value={count} />
                <span className="text-[16px] font-medium" style={{ color: "var(--muted)" }}>
                  {count > 1 ? "outils" : "outil"}
                </span>
              </div>
            </div>

            {/* Right: convergence hub */}
            <div ref={ref} className="relative min-h-[420px] md:min-h-[480px]">
              <ConvergenceHub
                settle={settle}
                hubScale={hubScale}
                hubOpacity={hubOpacity}
                chipsDim={chipsDim}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Counter20to1({ inView, value }: { inView: boolean; value: number }) {
  return (
    <motion.span
      className="font-semibold"
      style={{
        fontFamily: "var(--font-display)",
        fontSize: "clamp(3rem,6vw,4.5rem)",
        letterSpacing: "-0.03em",
        color: "var(--ink)",
        fontVariantNumeric: "tabular-nums",
      }}
    >
      {value}
    </motion.span>
  );
}

function ConvergenceHub({
  settle,
  hubScale,
  hubOpacity,
  chipsDim,
}: {
  settle: any;
  hubScale: any;
  hubOpacity: any;
  chipsDim: any;
}) {
  // reduced motion: show static final state
  const [reduce, setReduce] = useState(false);
  useEffect(() => {
    setReduce(
      typeof window !== "undefined" &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    );
  }, []);

  const cx = 50;
  const cy = 50;

  return (
    <div className="absolute inset-0">
      {/* SVG beams: green -> violet, staggered */}
      <svg className="absolute inset-0 h-full w-full" style={{ overflow: "visible" }} aria-hidden>
        {POS.map((p, i) => {
          const startX = p.side === "L" ? `${p.x}%` : `${100 - p.x}%`;
          const startY = `${p.y}%`;
          const endX = "50%";
          const endY = "50%";
          const midX = p.side === "L" ? "32%" : "68%";
          const midY = `${(p.y + 50) / 2}%`;
          return (
            <motion.path
              key={i}
              d={`M ${startX} ${startY} Q ${midX} ${midY} ${endX} ${endY}`}
              fill="none"
              stroke="url(#beam)"
              strokeWidth="1.5"
              strokeOpacity={0.5}
              initial={{ pathLength: 0 }}
              animate={reduce ? { pathLength: 1 } : inViewAnim(i)}
              transition={{ duration: 1, delay: 0.3 + i * 0.04, ease: [0.16, 1, 0.3, 1] }}
            />
          );
        })}
        <defs>
          <linearGradient id="beam" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--green)" stopOpacity="0.1" />
            <stop offset="60%" stopColor="var(--green)" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#16a34a" stopOpacity="0.7" />
          </linearGradient>
        </defs>
      </svg>

      {/* chips in two arcs */}
      <motion.div style={{ opacity: reduce ? 0.6 : chipsDim }} className="absolute inset-0">
        {TOOLS.map((t, i) => {
          const p = POS[i];
          const left = p.side === "L" ? `${p.x}%` : `${100 - p.x - 14}%`;
          const top = `${p.y}%`;
          return (
            <motion.div
              key={t}
              initial={{ x: p.side === "L" ? -40 : 40, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: i * 0.03, ease: [0.16, 1, 0.3, 1] }}
              className="absolute flex items-center gap-1.5 rounded-full border bg-white px-3 py-2 text-[12px] font-medium"
              style={{
                left,
                top,
                borderColor: "var(--line-strong)",
                color: "var(--text)",
                boxShadow: "var(--shadow-sm)",
              }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--green)" }} />
              {t}
            </motion.div>
          );
        })}
      </motion.div>

      {/* center hub — light card pops on white panel with green->violet ring + border beam */}
      <motion.div
        style={{ scale: reduce ? 1 : hubScale, opacity: reduce ? 1 : hubOpacity }}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
      >
        <div className="relative">
          {/* border beam ring */}
          <div
            aria-hidden
            className="pointer-events-none absolute -inset-[2px] rounded-[20px]"
            style={{
              background: "conic-gradient(from 0deg, var(--green), #16a34a, var(--green))",
              padding: "1.5px",
              WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
              WebkitMaskComposite: "xor",
              maskComposite: "exclude",
              animation: "cx-spin 8s linear infinite",
            }}
          />
          <div
            className="relative flex flex-col items-center gap-3 rounded-[20px] bg-white px-7 py-6"
            style={{ boxShadow: "0 12px 40px -8px rgba(50,220,50,0.35)" }}
          >
            <div
              className="flex h-12 w-12 items-center justify-center rounded-2xl"
              style={{ background: "var(--tint-green)" }}
            >
              <img
                src={CLIENTX_LOGO}
                alt="ClientX AI"
                className="h-7 w-auto object-contain"
                style={{ filter: "brightness(0)" }}
              />
            </div>
            <span className="text-[13px] font-semibold" style={{ color: "var(--ink)" }}>
              Un seul logiciel IA.
            </span>
          </div>
        </div>
      </motion.div>

      <style>{`@keyframes cx-spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function inViewAnim(i: number) {
  return { pathLength: 1 };
}

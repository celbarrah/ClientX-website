import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { TrendUp, SealCheck } from "@phosphor-icons/react";
import { Eyebrow } from "./primitives";
import { PrimaryButton, SecondaryButton } from "./Buttons";
import { ClientOnly } from "./ClientOnly";
import { ModuleMock } from "./ModuleMock";

/* Stats — final values are server-rendered; count-up plays on view.
   Green glyphs (+, %, €) are the only green accent on the violet panel. */
const STATS = [
  { final: "0 €", label: "De coûts cachés", num: 0, suffix: " €", glyph: "€" },
  {
    final: "+20 outils",
    label: "Réunis en 1 plateforme",
    num: 20,
    prefix: "+",
    suffix: " outils",
    glyph: "+",
  },
  { final: "ISO 9001", label: "Entreprise certifiée", raw: "ISO 9001", glyph: "" },
  { final: "100%", label: "Flux unifiés & sécurisés", num: 100, suffix: "%", glyph: "%" },
];

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef as React.RefObject<HTMLElement>,
    offset: ["start start", "end start"],
  });
  const dashTilt = useTransform(scrollYProgress, [0, 1], [1, 0]);

  return (
    <section
      ref={sectionRef}
      className="rails-bg relative overflow-hidden"
      style={{ backgroundColor: "#ffffff" }}
    >
      {/* masked line grid + green glow */}
      <div aria-hidden className="pointer-events-none absolute inset-0 grid-bg" />
      <div
        aria-hidden
        className="pointer-events-none absolute right-[6%] top-[6%] h-[440px] w-[440px] blur-[120px]"
        style={{
          background: "radial-gradient(circle, var(--green) 0%, transparent 70%)",
          opacity: 0.1,
        }}
      />
      {/* line waves at the bottom */}
      <LineWaves />

      <div className="container-x relative grid items-center gap-12 pt-28 md:pt-32 lg:grid-cols-[1.05fr_1fr]">
        {/* Left */}
        <div>
          <Eyebrow>N°1 Logiciel IA Business All-in-One</Eyebrow>
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1], delay: 0.05 }}
            className="text-balance mt-6 font-semibold"
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "clamp(2.6rem, 5.2vw, 4.6rem)",
              letterSpacing: "-0.035em",
              lineHeight: 1.02,
              color: "#000000",
            }}
          >
            Un seul logiciel IA. Tout votre business.{" "}
            <span style={{ color: "var(--green-text)" }}>Zéro friction.</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
            className="text-pretty mt-6 max-w-[40rem] text-[17px] leading-relaxed"
            style={{ color: "var(--muted)" }}
          >
            ClientX rassemble{" "}
            <span style={{ color: "var(--ink)", fontWeight: 500 }}>
              vos pages web, votre CRM, vos emails, vos rendez-vous, vos paiements et vos formations
            </span>{" "}
            dans une plateforme logicielle IA unifiée, propulsée par un puissant moteur
            d'automatisation natif.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1], delay: 0.25 }}
            className="mt-9 flex flex-wrap items-center gap-3"
          >
            <PrimaryButton to="/contact">Réserver une Démo</PrimaryButton>
            <SecondaryButton to="#plateforme">Découvrir la plateforme</SecondaryButton>
          </motion.div>
        </div>

        {/* Right: product visual — tilt-to-flat on scroll */}
        <HeroVisual tiltProgress={dashTilt} />
      </div>

      {/* Violet stats panel */}
      <div className="container-x relative mt-16 md:mt-20">
        <VioletStats />
      </div>
      <div className="h-16" />
    </section>
  );
}

/* ---------- Brand Green stats panel (Image 2 style) ---------- */
function VioletStats() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="relative overflow-hidden rounded-[28px] p-5 md:p-8"
      style={{
        background: "linear-gradient(135deg, #104e20 0%, #166e2c 35%, #1fa244 75%, #32dc32 100%)",
        boxShadow: "0 24px 60px -15px rgba(50, 220, 50, 0.45)",
      }}
    >
      {/* line grid pattern */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-15"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.15) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />
      <div className="relative grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        {STATS.map((s, i) => (
          <StatCard key={i} {...s} />
        ))}
      </div>
    </motion.div>
  );
}

function StatCard({ num, label, prefix, suffix, raw, glyph }: any) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.4 });
  const [val] = useCount(num || 0, inView);

  return (
    <div
      ref={ref}
      className="relative overflow-hidden rounded-[20px] p-5 md:p-7 text-center flex flex-col items-center justify-center"
      style={{
        background: "rgba(255, 255, 255, 0.12)",
        border: "1px solid rgba(255, 255, 255, 0.25)",
        backdropFilter: "blur(12px)",
        boxShadow: "inset 0 1px 0 rgba(255, 255, 255, 0.3)",
      }}
    >
      {/* faint oversized background numeral */}
      {raw ? (
        <span
          aria-hidden
          className="pointer-events-none absolute -bottom-6 -right-2 select-none font-semibold leading-none"
          style={{
            fontSize: "clamp(5rem,9vw,8rem)",
            color: "rgba(255,255,255,0.06)",
            fontVariantNumeric: "tabular-nums",
          }}
        >
          ISO
        </span>
      ) : (
        <span
          aria-hidden
          className="pointer-events-none absolute -bottom-6 -right-2 select-none font-semibold leading-none"
          style={{
            fontSize: "clamp(5rem,9vw,8rem)",
            color: "rgba(255,255,255,0.06)",
            fontVariantNumeric: "tabular-nums",
          }}
        >
          {num}
        </span>
      )}
      <div
        className="relative whitespace-nowrap font-semibold"
        style={{
          fontFamily: "var(--font-display)",
          fontSize: "clamp(2rem,3.4vw,3rem)",
          letterSpacing: "-0.03em",
          color: "#ffffff",
          fontVariantNumeric: "tabular-nums",
        }}
      >
        {raw ? (
          raw
        ) : (
          <>
            {prefix && <span style={{ color: "#32dc32" }}>{prefix}</span>}
            {num === 0 ? "0" : <span>{val}</span>}
            {suffix && (
              <span style={{ color: glyph === "%" ? "#32dc32" : undefined }}>
                {suffix === " €" ? " €" : suffix === " outils" ? " outils" : suffix}
              </span>
            )}
          </>
        )}
      </div>
      <div
        className="relative mt-2 text-[12px] font-semibold uppercase tracking-wider"
        style={{
          fontFamily: "var(--font-mono)",
          color: "rgba(255, 255, 255, 0.85)",
        }}
      >
        {label}
      </div>
    </div>
  );
}

/* tiny count-up hook — SSR-safe: server-renders the FINAL value so crawlers and
   the initial paint never show "0". The animation only runs as a progressive
   enhancement after hydration + in-view + motion allowed. */
function useCount(to: number, inView: boolean) {
  const [val, setVal] = useState(to); // final value on server + first paint
  const started = useRef(false);

  useEffect(() => {
    if (!inView || started.current) return;
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setVal(to);
      started.current = true;
      return;
    }
    started.current = true;
    let raf = 0;
    const start = performance.now();
    const dur = 1200;
    const step = (now: number) => {
      const p = Math.min((now - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(to * eased));
      if (p < 1) raf = requestAnimationFrame(step);
      else setVal(to);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);

  return [val, setVal] as const;
}

/* ---------- Line waves (thin SVG sine paths, transform-animated) ---------- */
function LineWaves() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-x-0 bottom-0 h-24 overflow-hidden"
    >
      <svg
        className="absolute bottom-0 w-[200%]"
        viewBox="0 0 1440 80"
        preserveAspectRatio="none"
        style={{ height: 60 }}
      >
        <motion.path
          d="M0,40 C180,10 360,70 540,40 C720,10 900,70 1080,40 C1260,10 1440,70 1620,40 C1800,10 1980,70 2160,40 C2340,10 2520,70 2700,40 C2880,10 3060,70 3240,40"
          fill="none"
          stroke="var(--green)"
          strokeWidth="1"
          style={{ opacity: 0.22 }}
          animate={{ x: [0, -1440] }}
          transition={{ duration: 22, repeat: Infinity, ease: "linear" }}
        />
      </svg>
      <svg
        className="absolute bottom-2 w-[200%]"
        viewBox="0 0 1440 80"
        preserveAspectRatio="none"
        style={{ height: 50 }}
      >
        <motion.path
          d="M0,40 C180,60 360,20 540,40 C720,60 900,20 1080,40 C1260,60 1440,20 1620,40 C1800,60 1980,20 2160,40 C2340,60 2520,20 2700,40 C2880,60 3060,20 3240,40"
          fill="none"
          stroke="var(--green)"
          strokeWidth="1"
          style={{ opacity: 0.15 }}
          animate={{ x: [-1440, 0] }}
          transition={{ duration: 28, repeat: Infinity, ease: "linear" }}
        />
      </svg>
    </div>
  );
}

/* ---------- Hero product visual ---------- */
function HeroVisual({ tiltProgress }: { tiltProgress: any }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  return (
    <motion.div
      ref={wrapRef}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
      className="relative"
    >
      <ClientOnly fallback={<HeroPlaceholder />}>
        <ProductFrame onMouseParent={wrapRef} tiltProgress={tiltProgress} />
      </ClientOnly>

      {/* Floating chips */}
      <div
        className="absolute -bottom-5 left-2 z-10 flex items-center gap-2 rounded-2xl border bg-white px-3.5 py-2.5 shadow-lg md:-left-5"
        style={{ borderColor: "var(--line)", boxShadow: "var(--shadow-lg)" }}
      >
        <span
          className="grid h-8 w-8 place-items-center rounded-lg"
          style={{ background: "var(--green-soft)", color: "var(--green-text)" }}
        >
          <TrendUp className="h-4 w-4" weight="bold" />
        </span>
        <div>
          <div className="text-[11px]" style={{ color: "var(--muted)" }}>
            Conversion
          </div>
          <div
            className="text-[14px] font-semibold"
            style={{ color: "var(--ink)", fontVariantNumeric: "tabular-nums" }}
          >
            34,2 %
          </div>
        </div>
      </div>

      <div
        className="absolute -right-3 top-6 z-10 flex items-center gap-2 rounded-2xl border bg-white px-3.5 py-2.5 shadow-lg md:-right-5"
        style={{ borderColor: "var(--line)", boxShadow: "var(--shadow-lg)" }}
      >
        <span
          className="grid h-8 w-8 place-items-center rounded-lg"
          style={{ background: "var(--green-soft)", color: "var(--green-text)" }}
        >
          <SealCheck className="h-4 w-4" weight="fill" />
        </span>
        <div>
          <div className="text-[11px]" style={{ color: "var(--muted)" }}>
            Entreprise certifiée
          </div>
          <div className="text-[14px] font-semibold" style={{ color: "var(--ink)" }}>
            ISO 9001
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function ProductFrame({
  onMouseParent,
  tiltProgress,
}: {
  onMouseParent: React.RefObject<HTMLDivElement | null>;
  tiltProgress: any;
}) {
  const handleMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = onMouseParent.current;
    if (!el || (typeof window !== "undefined" && window.matchMedia("(hover: none)").matches))
      return;
    const r = el.getBoundingClientRect();
    const mx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
    const my = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
    el.style.transform = `perspective(1600px) rotateY(${8 - mx * 6}deg) rotateX(${4 + my * 4}deg)`;
  };
  const reset = () => {
    if (onMouseParent.current)
      onMouseParent.current.style.transform = "perspective(1600px) rotateY(-8deg) rotateX(4deg)";
  };
  return (
    <motion.div
      onMouseMove={handleMove}
      onMouseLeave={reset}
      style={{
        transform: "perspective(1600px) rotateY(-8deg) rotateX(4deg)",
        transition: "transform 0.4s var(--ease-expo)",
      }}
    >
      <BrowserFrame label="Dashboard" />
    </motion.div>
  );
}

function BrowserFrame({ label }: { label: string }) {
  return (
    <div className="frame">
      <div
        className="flex items-center gap-2 border-b px-4 py-3"
        style={{ borderColor: "var(--line)" }}
      >
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#ff5f57" }} />
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#febc2e" }} />
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#28c840" }} />
        <span className="ml-2 text-[11px]" style={{ color: "var(--muted)" }}>
          {label}
        </span>
      </div>
      <div className="aspect-[16/10] p-5">
        <ModuleMock kind="ClientX Dashboard" />
      </div>
    </div>
  );
}

function HeroPlaceholder() {
  return (
    <div className="frame">
      <div
        className="flex items-center gap-2 border-b px-4 py-3"
        style={{ borderColor: "var(--line)" }}
      >
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#ff5f57" }} />
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#febc2e" }} />
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: "#28c840" }} />
      </div>
      <div className="aspect-[16/10] p-5">
        <ModuleMock kind="ClientX Dashboard" />
      </div>
    </div>
  );
}

export function Placeholder({ label, className = "" }: { label: string; className?: string }) {
  return (
    <div className={`h-full w-full ${className}`}>
      <ModuleMock kind={label} />
    </div>
  );
}

import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from "framer-motion";
import { List, X, CaretUp } from "@phosphor-icons/react";
import { CLIENTX_LOGO } from "../../lib/site";
import { PrimaryButton } from "./Buttons";

const EASE = [0.16, 1, 0.3, 1] as const;

const NAV = [
  { label: "Plateforme & Features", to: "/fonctionnalites", match: "/fonctionnalites" },
  { label: "Cas Clients", to: "/cas-clients", match: "/cas-clients" },
  { label: "Nos Tarifs", to: "/tarifs", match: "/tarifs" },
];

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { scrollY } = useScroll();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useMotionValueEvent(scrollY, "change", (y) => setScrolled(y > 8));

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  return (
    <header
      className="fixed left-0 right-0 top-0 z-[100] flex justify-center"
      style={{
        height: 68,
        background: scrolled ? "rgba(255,255,255,0.8)" : "rgba(255,255,255,0)",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid var(--line)" : "1px solid transparent",
        transition: "background 0.3s var(--ease-expo), border-color 0.3s var(--ease-expo)",
      }}
    >
      <div className="flex h-full w-full max-w-[1200px] items-center justify-between px-5 md:px-8">
        <Link to="/" className="flex items-center" aria-label="ClientX AI accueil">
          <img
            src={CLIENTX_LOGO}
            alt="ClientX AI"
            className="h-7 w-auto"
            style={{ filter: "brightness(0)" }}
          />
        </Link>

        <nav className="hidden items-center gap-7 md:flex">
          {NAV.map((n) => {
            const active = pathname === n.match;
            return (
              <Link
                key={n.to}
                to={n.to}
                className="relative text-[14px] font-medium transition-colors"
                style={{ color: active ? "var(--ink)" : "var(--muted)" }}
              >
                {n.label}
                {active && (
                  <span
                    className="absolute -bottom-1.5 left-0 right-0 h-0.5 rounded-full"
                    style={{ background: "var(--green)" }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden md:block">
            <PrimaryButton to="/contact">Réserver une Démo</PrimaryButton>
          </div>
          <button
            onClick={() => setMenuOpen(true)}
            aria-label="Ouvrir le menu"
            className="grid h-11 w-11 place-items-center rounded-full border md:hidden"
            style={{ borderColor: "var(--line)", color: "var(--ink)" }}
          >
            <List className="h-5 w-5" weight="regular" />
          </button>
        </div>
      </div>

      {/* Mobile overlay */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[105] flex flex-col bg-white px-6 pt-6 md:hidden"
          >
            <div className="flex items-center justify-between">
              <img
                src={CLIENTX_LOGO}
                alt="ClientX AI"
                className="h-7 w-auto"
                style={{ filter: "brightness(0)" }}
              />
              <button
                onClick={() => setMenuOpen(false)}
                aria-label="Fermer le menu"
                className="grid h-11 w-11 place-items-center rounded-full border"
                style={{ borderColor: "var(--line)", color: "var(--ink)" }}
              >
                <X className="h-5 w-5" weight="regular" />
              </button>
            </div>
            <div className="mt-16 flex flex-col gap-5">
              {NAV.map((n, i) => (
                <motion.div
                  key={n.to}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 + i * 0.06, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                >
                  <Link
                    to={n.to}
                    onClick={() => setMenuOpen(false)}
                    className="block text-[clamp(1.6rem, 6vw, 2.2rem)] font-semibold"
                    style={{
                      fontFamily: "var(--font-display)",
                      letterSpacing: "-0.03em",
                      color: "var(--ink)",
                    }}
                  >
                    {n.label}
                  </Link>
                </motion.div>
              ))}
            </div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-auto pb-10"
            >
              <PrimaryButton to="/contact" className="w-full">
                Réserver une Démo
              </PrimaryButton>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

export function SiteFooter() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 800);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <footer
      className="relative overflow-hidden"
      style={{
        backgroundColor: "var(--bg-soft)",
        borderTop: "1px solid var(--line)",
      }}
    >
      <div className="container-x py-16 md:py-24">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-12 md:gap-8">
          {/* Column 1: ClientX Brand + Intro */}
          <div className="md:col-span-5">
            <div className="flex items-center">
              <img
                src={CLIENTX_LOGO}
                alt="ClientX AI"
                className="h-7 w-auto"
                style={{ filter: "brightness(0)" }}
              />
            </div>
            <p
              className="mt-6 max-w-[26rem] text-[14px] leading-relaxed md:text-[15px]"
              style={{ color: "var(--text)" }}
            >
              Le logiciel tout-en-un qui centralise vos sites, votre CRM, vos emails, vos
              calendriers et vos automatisations. Augmentez vos résultats sans multiplier vos
              abonnements.
            </p>
            <p className="label mt-6" style={{ color: "var(--faint)" }}>
              Certifié ISO 9001 • MENA &amp; Europe
            </p>
          </div>

          {/* Column 2: Plateforme All-In-One */}
          <div className="md:col-span-4 md:col-start-7">
            <h4 className="label" style={{ color: "var(--faint)" }}>
              Plateforme All-In-One
            </h4>
            <ul className="mt-5 space-y-3 text-[14px]">
              {[
                "Sites & Tunnels de Vente",
                "CRM Systémique Unifié",
                "Email, SMS & WhatsApp",
                "Calendriers & Rendez-vous",
                "Formations & E-learning",
                "Automatisations & Workflows",
              ].map((item) => (
                <li key={item}>
                  <Link to="/fonctionnalites" className="footer-link">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Ressources */}
          <div className="md:col-span-3">
            <h4 className="label" style={{ color: "var(--faint)" }}>
              Ressources
            </h4>
            <ul className="mt-5 space-y-3 text-[14px]">
              <li>
                <Link to="/cas-clients" className="footer-link">
                  Cas Clients par Secteur
                </Link>
              </li>
              <li>
                <Link to="/fonctionnalites" className="footer-link">
                  Fonctionnalités
                </Link>
              </li>
              <li>
                <Link to="/tarifs" className="footer-link">
                  Nos Tarifs
                </Link>
              </li>
              <li>
                <Link to="/contact" className="footer-link">
                  Réserver une Démo
                </Link>
              </li>
              <li>
                <Link to="/contact" className="footer-link">
                  Onboarding &amp; Support
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom legal bar */}
        <div
          className="mt-16 flex flex-col items-center justify-between gap-4 border-t pt-6 text-[12px] md:flex-row"
          style={{ borderColor: "var(--line)", color: "var(--muted)" }}
        >
          <p>© 2013–2026 ClientX AI by Webeuz. Tous droits réservés. · ClientX Ltd · WBX SARL</p>
          <p className="hidden md:block" style={{ color: "var(--faint)" }}>
            ClientX est propulsé par la puissance systémique All-in-One
          </p>
          <div className="flex gap-6">
            <Link to="/mentions-legales" className="footer-link">
              Mentions Légales
            </Link>
            <Link to="/confidentialite" className="footer-link">
              Confidentialité
            </Link>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="Retour en haut"
            className="fixed bottom-6 right-6 z-[90] grid h-10 w-10 place-items-center rounded-full border shadow-lg transition-transform hover:scale-110"
            style={{
              borderColor: "var(--line-strong)",
              background: "var(--surface)",
              color: "var(--ink)",
            }}
          >
            <CaretUp className="h-5 w-5" weight="bold" />
          </motion.button>
        )}
      </AnimatePresence>
    </footer>
  );
}

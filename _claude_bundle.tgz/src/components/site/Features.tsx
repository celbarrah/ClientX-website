import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { FEATURES } from "../../lib/site";
import { SectionHeader } from "./primitives";
import { ModuleMock } from "./ModuleMock";

const EASE = [0.16, 1, 0.3, 1] as const;

// Bento cell config (desktop, 12-col grid).
// dark => ink background (the single dark accent), tint => green-soft or violet,
// bleed => mockup bleeds off bottom edge, tall => larger cell.
const BENTO = [
  { span: "lg:col-span-6 lg:row-span-2", tall: true, bleed: true },
  { span: "lg:col-span-3 lg:row-span-2", tall: true, bleed: true },
  { span: "lg:col-span-3", bleed: true },
  { span: "lg:col-span-3", dark: true, bleed: true },
  { span: "lg:col-span-3", bleed: true },
  { span: "lg:col-span-4", tint: "green", bleed: true },
  { span: "lg:col-span-4", bleed: true },
  { span: "lg:col-span-4", bleed: true },
  { span: "lg:col-span-4", tint: "green", bleed: true },
  // 9th maps to the last feature; layout: row4 covers last 2? We use a 12-col:
  // r1: 6+3 (+3 carried) — simplified below.
] as const;

export function FeaturesSection() {
  return (
    <section
      id="plateforme"
      className="rails-bg py-16 md:py-24"
      style={{ backgroundColor: "var(--bg)", borderTop: "1px solid var(--line)" }}
    >
      <div className="container-x">
        <SectionHeader
          title={
            <>
              Un écosystème complet.{" "}
              <span style={{ color: "var(--green-text)" }}>Zéro outil manquant.</span>
            </>
          }
          paragraph="Tout ce dont vous avez besoin pour capturer, convertir, délivrer et fidéliser, déjà interconnecté nativement."
        />
        <div
          className="mt-10 overflow-hidden rounded-[24px] border"
          style={{
            borderColor: "var(--line-strong)",
            background: "var(--surface)",
            boxShadow: "var(--shadow-sm)",
          }}
        >
          <div
            className="grid grid-cols-1 gap-px md:grid-cols-2 lg:grid-cols-12 lg:auto-rows-[minmax(0,1fr)]"
            style={{ background: "var(--line)" }}
          >
            {FEATURES.map((f, i) => (
              <BentoCell key={f.index} feature={f} config={BENTO[i]} index={i} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function BentoCell({
  feature,
  config,
  index,
}: {
  feature: (typeof FEATURES)[number];
  config: (typeof BENTO)[number];
  index: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.2 });
  const isDark = "dark" in config ? config.dark : false;
  const tint = "tint" in config ? config.tint : false;
  const isTall = "tall" in config ? config.tall : false;
  const bleed = "bleed" in config ? config.bleed : false;
  const Icon = feature.icon;

  const bg = isDark
    ? "#000000"
    : tint === "green"
      ? "var(--tint-green)"
      : tint === "violet"
        ? "#f8f9fa"
        : "#ffffff";
  const fg = isDark ? "#ffffff" : "#000000";

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 16 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, ease: EASE, delay: (index % 4) * 0.05 }}
      className={`group relative flex flex-col overflow-hidden p-6 md:p-7 ${config.span}`}
      style={{ background: bg, color: fg }}
    >
      {/* text block at top */}
      <div className="relative z-10">
        <div className="flex items-center gap-2.5">
          <span
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl"
            style={{
              background: isDark ? "rgba(255,255,255,0.1)" : tint ? "#fff" : "var(--green-soft)",
              color: isDark ? "var(--green)" : "var(--green-text)",
              border: isDark ? "1px solid rgba(255,255,255,0.12)" : "1px solid var(--line)",
            }}
          >
            <Icon className="h-5 w-5" weight="regular" />
          </span>
          <span
            className="rounded-full px-2.5 py-1 text-[11px] font-medium"
            style={{
              background: isDark ? "rgba(255,255,255,0.1)" : "#fff",
              color: isDark ? "rgba(255,255,255,0.8)" : "var(--muted)",
              border: isDark ? "1px solid rgba(255,255,255,0.12)" : "1px solid var(--line)",
            }}
          >
            {feature.category}
          </span>
        </div>
        <h3 className="mt-4 text-[1.2rem] font-semibold" style={{ letterSpacing: "-0.02em" }}>
          {feature.title}
        </h3>
        <p
          className="text-pretty mt-2 max-w-[34ch] text-[14px] leading-relaxed"
          style={{ color: isDark ? "rgba(255,255,255,0.72)" : "var(--muted)" }}
        >
          {feature.desc}
        </p>
      </div>

      {/* mockup anchored to bottom, bleeds off edge */}
      <div
        className={`relative z-0 mt-auto ${bleed ? "-mx-6 -mb-6 px-5 pb-5 md:-mx-7 md:px-6 md:pb-6" : "pt-5"}`}
        style={isTall ? { flex: "1 1 auto" } : undefined}
      >
        <div
          style={{
            filter: isDark ? "brightness(1.15) saturate(1.1)" : "none",
            transform: isTall ? "scale(1.05)" : "scale(1.02)",
            transformOrigin: "bottom center",
          }}
        >
          <ModuleMock kind={feature.title} dark={isDark} />
        </div>
      </div>
    </motion.div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { PageHero, PageMain, FooterCTA, SpotlightPanel } from "../components/site/primitives";
import {
  PricingCards,
  IncludedGroupsSection,
  AIAgentsSection,
  RegionSwitch,
  defaultRegion,
  type Region,
} from "../components/site/Pricing";
import { FaqSection } from "../components/site/Faq";

export const Route = createFileRoute("/tarifs")({
  head: () => ({
    meta: [
      { title: "Nos Tarifs & Abonnements — ClientX AI" },
      {
        name: "description",
        content:
          "Découvrez les tarifs transparents de ClientX AI. Forfaits tout-inclus sans engagement avec accompagnement 1:1 et certification ISO 9001.",
      },
      { property: "og:title", content: "Nos Tarifs & Abonnements — ClientX AI" },
      {
        property: "og:description",
        content: "Remplacez plus de 20 logiciels dispersés par une solution unifiée tout-inclus.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TarifsPage,
});

function TarifsPage() {
  const [region, setRegion] = useState<Region>("fr");
  useEffect(() => setRegion(defaultRegion()), []);

  return (
    <PageMain>
      <PageHero
        align="center"
        eyebrow={
          <span
            className="inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[13px] font-medium"
            style={{ background: "var(--green-soft)", color: "var(--green-text)" }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--green)" }} />
            Tarifs · Paiement annuel
          </span>
        }
        title={
          <>
            Choisissez le plan adapté à votre{" "}
            <span style={{ color: "var(--green-text)" }}>ambition.</span>
          </>
        }
        paragraph="Un seul logiciel IA pour vos sites, votre CRM, vos emails, vos rendez-vous et vos automatisations."
      />

      <div className="container-x pb-4">
        <p className="text-center text-[15px]" style={{ color: "var(--muted)" }}>
          Paiement annuel, possible en deux fois.
        </p>
      </div>

      {/* Pricing — White Section */}
      <section className="py-8 md:py-12">
        <div className="container-x">
          <div className="flex flex-col items-center text-center">
            <div className="mt-2">
              <RegionSwitch region={region} setRegion={setRegion} />
            </div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4 }}
              key={region}
              className="mt-12 w-full"
            >
              <PricingCards region={region} ctaTo="/contact" />
            </motion.div>
            <p className="mt-8 text-[13px]" style={{ color: "var(--muted)" }}>
              Prix par an, paiement annuel uniquement. « 2 × » indique le paiement échelonné en deux
              fois.
            </p>
          </div>
        </div>
      </section>

      <IncludedGroupsSection />
      <AIAgentsSection />
      <FaqSection align="left" />
      <FooterCTA />
    </PageMain>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Check, ArrowRight } from "@phosphor-icons/react";
import { PageHero, PageMain, FooterCTA } from "../components/site/primitives";
import { PrimaryButton } from "../components/site/Buttons";
import { Placeholder } from "../components/site/Hero";
import { MODULES } from "../lib/modules-data";

export const Route = createFileRoute("/fonctionnalites")({
  head: () => ({
    meta: [
      { title: "Plateforme All-in-One ClientX AI — Fonctionnalités" },
      {
        name: "description",
        content:
          "Découvrez toutes les fonctionnalités unifiées de ClientX : Tunnels, CRM, Email, WhatsApp, Calendriers, Formations et Automatisations.",
      },
      { property: "og:title", content: "Plateforme All-in-One ClientX AI — Fonctionnalités" },
      {
        property: "og:description",
        content:
          "Sites, CRM, Emails, Calendriers, Formations & Automatisations réunis dans une seule plateforme.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FonctionnalitesPage,
});

const EASE = [0.16, 1, 0.3, 1] as const;

function FonctionnalitesPage() {
  const [activeId, setActiveId] = useState(MODULES[0].id);
  const sectionRefs = useRef<Record<string, HTMLElement | null>>({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const id = (entry.target as HTMLElement).dataset.moduleId;
            if (id) setActiveId(id);
          }
        }
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );
    Object.values(sectionRefs.current).forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const scrollToModule = (id: string) => {
    const el = sectionRefs.current[id];
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 120;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <PageMain>
      {/* Hero: left text + right screenshot collage */}
      <section className="relative overflow-hidden pt-32 md:pt-36">
        <div aria-hidden className="pointer-events-none absolute inset-0 grid-bg" />
        <div className="container-x relative grid items-center gap-12 lg:grid-cols-[1.05fr_1fr]">
          <div className="max-w-[46rem]">
            <span
              className="inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[13px] font-medium"
              style={{ background: "var(--green-soft)", color: "var(--green-text)" }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--green)" }} />
              Tout votre business au même endroit
            </span>
            <motion.h1
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5, ease: EASE }}
              className="text-balance mt-6 font-semibold"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2.6rem,5.2vw,4.6rem)",
                letterSpacing: "-0.035em",
                lineHeight: 1.02,
                color: "var(--ink)",
              }}
            >
              Une Plateforme <span style={{ color: "var(--green-text)" }}>Sans Limite</span>
            </motion.h1>
            <p
              className="text-pretty mt-6 max-w-[40rem] text-[17px] leading-relaxed"
              style={{ color: "var(--muted)" }}
            >
              Remplacez plus de 20 abonnements isolés par un seul système unifié où chaque outil
              enrichit le suivant.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <PrimaryButton to="/contact">Réserver une Démo</PrimaryButton>
            </div>
          </div>

          {/* Collage of 3 overlapping screenshots */}
          <div className="relative hidden h-[340px] lg:block">
            <div className="frame absolute left-0 top-0 w-[62%]" style={{ zIndex: 2 }}>
              <div className="aspect-[16/10] p-4">
                <Placeholder label="Funnel Builder" />
              </div>
            </div>
            <div className="frame absolute right-0 top-12 w-[58%]" style={{ zIndex: 3 }}>
              <div className="aspect-[16/10] p-4">
                <Placeholder label="Pipeline CRM" />
              </div>
            </div>
            <div className="frame absolute bottom-0 left-10 w-[56%]" style={{ zIndex: 4 }}>
              <div className="aspect-[16/10] p-4">
                <Placeholder label="Inbox Unifiée" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sticky sub-nav */}
      <div
        className="sticky top-[68px] z-40 mt-4 bg-white/80 backdrop-blur"
        style={{ borderBottom: "1px solid var(--line)" }}
      >
        <div className="container-x">
          <div className="no-scrollbar flex max-w-full gap-1 overflow-x-auto py-3">
            {MODULES.map((m) => {
              const isActive = activeId === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => scrollToModule(m.id)}
                  className="relative shrink-0 rounded-full px-3.5 py-2 text-[13px] font-medium transition-colors"
                  style={{ color: isActive ? "var(--ink)" : "var(--muted)" }}
                >
                  {isActive && (
                    <motion.span
                      layoutId="mod-nav"
                      className="absolute inset-0 rounded-full"
                      style={{ background: "var(--green-soft)" }}
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative whitespace-nowrap">{m.title}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Modules with rhythm */}
      <div className="container-x py-16 md:py-24">
        <div className="space-y-20 md:space-y-28">
          {MODULES.map((m, i) => {
            const layout = getLayout(i);
            const Icon = m.icon;
            return (
              <section
                key={m.id}
                data-module-id={m.id}
                ref={(el) => {
                  sectionRefs.current[m.id] = el;
                }}
              >
                {layout === "split" && <SplitRow m={m} i={i} Icon={Icon} />}
                {layout === "full" && <FullRow m={m} i={i} Icon={Icon} />}
                {layout === "cards" && <CardRow m={m} i={i} Icon={Icon} />}
                {layout === "dark" && <DarkRow m={m} i={i} Icon={Icon} />}
              </section>
            );
          })}
        </div>
      </div>

      {/* Final CTA band */}
      <div className="container-x pb-20">
        <div
          className="relative overflow-hidden rounded-[28px] px-6 py-16 text-center md:py-20"
          style={{ background: "var(--bg-tint)" }}
        >
          <div
            aria-hidden
            className="pointer-events-none absolute left-1/2 top-0 h-[300px] w-[500px] -translate-x-1/2 blur-[100px]"
            style={{
              background: "radial-gradient(circle, var(--green) 0%, transparent 70%)",
              opacity: 0.15,
            }}
          />
          <div className="relative mx-auto max-w-[40rem]">
            <h2
              className="text-balance font-semibold"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2rem,4vw,3rem)",
                letterSpacing: "-0.03em",
                color: "var(--ink)",
              }}
            >
              Prêt à unifier votre business ?
            </h2>
            <p
              className="text-pretty mx-auto mt-4 max-w-xl text-[16px]"
              style={{ color: "var(--muted)" }}
            >
              Passez à la simplicité ClientX AI et bénéficiez d'un onboarding technique 1:1 offert.
            </p>
            <div className="mt-8 flex justify-center">
              <PrimaryButton to="/contact">Réserver une Démo</PrimaryButton>
            </div>
          </div>
        </div>
      </div>
    </PageMain>
  );
}

/* Layout rhythm: 1-2 split, 3 full, 4-6 cards, 7-8 split, 9 dark */
function getLayout(i: number): "split" | "full" | "cards" | "dark" {
  if (i < 2) return "split";
  if (i === 2) return "full";
  if (i >= 3 && i <= 5) return "cards";
  if (i === 8) return "dark";
  return "split";
}

function ModuleText({
  m,
  Icon,
}: {
  m: (typeof MODULES)[number];
  Icon: (typeof MODULES)[number]["icon"];
}) {
  return (
    <div>
      <span
        className="grid h-11 w-11 place-items-center rounded-xl"
        style={{ background: "var(--green-soft)", color: "var(--green-text)" }}
      >
        <Icon className="h-6 w-6" weight="regular" />
      </span>
      <h2
        className="text-balance mt-5 font-semibold"
        style={{
          fontFamily: "var(--font-display)",
          fontSize: "clamp(1.8rem,3vw,2.6rem)",
          letterSpacing: "-0.02em",
          color: "var(--ink)",
        }}
      >
        {m.title}
      </h2>
      <p
        className="text-pretty mt-3 max-w-md text-[16px] leading-relaxed"
        style={{ color: "var(--muted)" }}
      >
        {m.desc}
      </p>
      <div className="mt-6 grid grid-cols-2 gap-3">
        {m.points.map((p) => (
          <div
            key={p}
            className="flex items-start gap-2 text-[13px]"
            style={{ color: "var(--muted)" }}
          >
            <span
              className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full"
              style={{ background: "var(--green-soft)" }}
            >
              <Check className="h-3 w-3" weight="bold" style={{ color: "var(--green-text)" }} />
            </span>
            <span>{p}</span>
          </div>
        ))}
      </div>
      <a
        href="/contact"
        className="group mt-7 inline-flex items-center gap-1.5 text-[14px] font-semibold"
        style={{ color: "var(--green-text)" }}
      >
        Réserver une Démo
        <ArrowRight
          className="h-4 w-4 transition-transform group-hover:translate-x-0.5"
          weight="bold"
        />
      </a>
    </div>
  );
}

function SplitRow({
  m,
  i,
  Icon,
}: {
  m: (typeof MODULES)[number];
  i: number;
  Icon: (typeof MODULES)[number]["icon"];
}) {
  const flip = i % 2 === 1;
  return (
    <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.5, ease: EASE }}
        className={flip ? "lg:order-2" : ""}
      >
        <ModuleText m={m} Icon={Icon} />
      </motion.div>
      <motion.div
        initial={{ opacity: 0, x: flip ? -30 : 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.6, ease: EASE }}
        className={flip ? "lg:order-1" : ""}
      >
        <div className="frame p-4">
          <div className="aspect-[16/10]">
            <Placeholder label={m.screenshot} />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function FullRow({
  m,
  Icon,
}: {
  m: (typeof MODULES)[number];
  i: number;
  Icon: (typeof MODULES)[number]["icon"];
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.5, ease: EASE }}
    >
      <div className="max-w-[44rem]">
        <ModuleText m={m} Icon={Icon} />
      </div>
      <div className="frame mt-8 p-4">
        <div className="aspect-[21/9]">
          <Placeholder label={m.screenshot} />
        </div>
      </div>
    </motion.div>
  );
}

function CardRow({
  m,
  Icon,
}: {
  m: (typeof MODULES)[number];
  i: number;
  Icon: (typeof MODULES)[number]["icon"];
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.5, ease: EASE }}
    >
      <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
        <ModuleText m={m} Icon={Icon} />
        <div className="frame p-4">
          <div className="aspect-[4/3]">
            <Placeholder label={m.screenshot} />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function DarkRow({
  m,
  Icon,
}: {
  m: (typeof MODULES)[number];
  i: number;
  Icon: (typeof MODULES)[number]["icon"];
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.5, ease: EASE }}
      className="overflow-hidden rounded-[28px] p-10 md:p-14"
      style={{ background: "var(--ink)" }}
    >
      <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-14">
        <div>
          <span
            className="grid h-11 w-11 place-items-center rounded-xl"
            style={{ background: "rgba(22,196,91,0.15)", color: "var(--green)" }}
          >
            <Icon className="h-6 w-6" weight="regular" />
          </span>
          <h2
            className="text-balance mt-5 font-semibold"
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "clamp(1.8rem,3vw,2.6rem)",
              letterSpacing: "-0.02em",
              color: "#fff",
            }}
          >
            {m.title}
          </h2>
          <p
            className="text-pretty mt-3 max-w-md text-[16px] leading-relaxed"
            style={{ color: "rgba(255,255,255,0.7)" }}
          >
            {m.desc}
          </p>
          <div className="mt-6 grid grid-cols-2 gap-3">
            {m.points.map((p) => (
              <div
                key={p}
                className="flex items-start gap-2 text-[13px]"
                style={{ color: "rgba(255,255,255,0.8)" }}
              >
                <span
                  className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full"
                  style={{ background: "var(--green)" }}
                >
                  <Check className="h-3 w-3" weight="bold" style={{ color: "var(--ink)" }} />
                </span>
                <span>{p}</span>
              </div>
            ))}
          </div>
        </div>
        <div
          className="frame overflow-hidden p-4"
          style={{ background: "rgba(255,255,255,0.04)", borderColor: "rgba(255,255,255,0.1)" }}
        >
          <div className="aspect-[4/3]">
            <Placeholder label={m.screenshot} className="!bg-transparent" />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { Homepage } from "../components/Homepage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ClientX AI — Logiciel IA Business All-in-One & CRM Systémique" },
      {
        name: "description",
        content:
          "Centralisez vos sites, tunnels, CRM, emails, calendriers et automatisations dans un logiciel IA tout-en-un unifié. Économisez plus de 15 000€ par an.",
      },
      {
        property: "og:title",
        content: "ClientX AI — Logiciel IA Business All-in-One",
      },
      {
        property: "og:description",
        content:
          "Le logiciel IA tout-en-un qui remplace vos 20 abonnements. Sites, CRM, Emails, Calendriers & Automatisations unifiés.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IndexPage,
});

function IndexPage() {
  return <Homepage />;
}
